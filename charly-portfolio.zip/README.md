
# Portfolio GEII — Charly VERDIERE-PARENT

## Installation

```bash
npm install
npm run dev
```

## Déploiement Vercel

1. Créer un dépôt GitHub
2. Envoyer le projet sur GitHub
3. Importer le dépôt dans Vercel
4. Déployer


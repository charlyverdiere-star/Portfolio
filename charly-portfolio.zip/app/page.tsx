
import { Cpu, Wrench, Network, Code2 } from "lucide-react";

export default function Home() {
  return (
    <main>

      <section className="section min-h-screen flex flex-col justify-center">
        <p className="subtitle">BUT GEII • Automatisme • Informatique industrielle</p>
        <h1 className="title max-w-4xl">
          Charly <br /> VERDIERE-PARENT
        </h1>

        <p className="text-lg max-w-2xl text-zinc-300 leading-8">
          Étudiant en Génie Électrique et Informatique Industrielle,
          passionné par l’automatisme, les systèmes industriels et les technologies innovantes.
        </p>
      </section>

      <section className="section">
        <div className="grid-2">
          <div>
            <p className="subtitle">À propos</p>
            <h2 className="title">Un intérêt né très jeune</h2>

            <p className="text-zinc-300 leading-8 text-lg">
              Depuis plus jeune, j’ai toujours été attiré par les environnements techniques et technologiques,
              notamment grâce à mon frère, qui a été une véritable source d’inspiration pour moi.
              En le voyant travailler sur différents projets durant ses études,
              j’ai progressivement développé une curiosité pour le fonctionnement des systèmes électroniques,
              informatiques et automatisés.
            </p>
          </div>

          <div className="card h-[500px] flex items-center justify-center">
            <p className="text-zinc-500">Ajouter ici une photo / image industrielle</p>
          </div>
        </div>
      </section>

      <section className="section">
        <p className="subtitle">Compétences</p>
        <h2 className="title">Compétences techniques</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
          <div className="card">
            <Cpu size={40} className="mb-4 text-blue-400" />
            <h3 className="text-2xl font-bold mb-3">Automatisme</h3>
            <p className="text-zinc-300">
              GRAFCET, Ladder, API Siemens, logique câblée, supervision industrielle.
            </p>
          </div>

          <div className="card">
            <Network size={40} className="mb-4 text-blue-400" />
            <h3 className="text-2xl font-bold mb-3">Réseaux industriels</h3>
            <p className="text-zinc-300">
              Communication automate/IHM, réseaux industriels et diagnostic.
            </p>
          </div>

          <div className="card">
            <Code2 size={40} className="mb-4 text-blue-400" />
            <h3 className="text-2xl font-bold mb-3">Programmation</h3>
            <p className="text-zinc-300">
              Python, C, Arduino et outils numériques industriels.
            </p>
          </div>

          <div className="card">
            <Wrench size={40} className="mb-4 text-blue-400" />
            <h3 className="text-2xl font-bold mb-3">Maintenance</h3>
            <p className="text-zinc-300">
              Diagnostic, dépannage et méthodologie industrielle.
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="grid-2">
          <div className="card h-[450px] flex items-center justify-center">
            <p className="text-zinc-500">Ajouter ici une image d’automatisme / industrie</p>
          </div>

          <div>
            <p className="subtitle">Projet professionnel</p>
            <h2 className="title">Construire des systèmes industriels performants</h2>

            <p className="text-zinc-300 leading-8 text-lg">
              Mon objectif est de poursuivre mes études en école d’ingénieur
              dans le domaine du Génie Électrique et de l’Informatique Industrielle,
              avec une spécialisation en automatisme et informatique industrielle.
              À long terme, je souhaite évoluer vers un poste d’ingénieur dans le domaine des systèmes industriels.
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        <p className="subtitle">Projets</p>
        <h2 className="title">Expériences et réalisations</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
          <div className="card">
            <h3 className="text-2xl font-bold mb-4">Palettiseur</h3>
            <p className="text-zinc-300">
              Création d’une IHM, communication automate/IHM et programmation d’une installation industrielle complexe.
            </p>
          </div>

          <div className="card">
            <h3 className="text-2xl font-bold mb-4">Sonde température</h3>
            <p className="text-zinc-300">
              Projet réalisé chez Renault avec ajout d’une sonde de température sur le moteur principal d’une presse.
            </p>
          </div>

          <div className="card">
            <h3 className="text-2xl font-bold mb-4">Découverte automatisme</h3>
            <p className="text-zinc-300">
              Initiation aux logigrammes, GRAFCET, Ladder et logique industrielle.
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        <p className="subtitle">Alternance</p>
        <h2 className="title">Renault Douai • Maintenance industrielle</h2>

        <p className="text-zinc-300 text-lg leading-8 max-w-4xl">
          Mon alternance au sein de l’usine George Besse de Renault à Douai m’a permis de développer
          des compétences techniques et humaines essentielles.
          J’ai progressivement appris à diagnostiquer des pannes, intervenir sur différents types
          d’installations industrielles et travailler dans un environnement exigeant.
        </p>
      </section>

      <section className="section">
        <p className="subtitle">CV</p>
        <h2 className="title">Curriculum Vitae</h2>

        <div className="card mt-10">
          <p className="text-zinc-300">
            Ajouter ici ton CV PDF téléchargeable.
          </p>
        </div>
      </section>

      <section className="section">
        <p className="subtitle">Contact</p>
        <h2 className="title">Entrons en contact</h2>

        <p className="text-zinc-300 text-lg leading-8">
          LinkedIn • GitHub • Adresse mail
        </p>
      </section>

    </main>
  );
}

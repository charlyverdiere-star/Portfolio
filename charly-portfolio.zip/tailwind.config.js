
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "#111315",
        surface: "#1B1E22",
        accent: "#4B7BEC",
        text: "#F5F5F5",
        muted: "#A0A0A0"
      }
    },
  },
  plugins: [],
}
